Before you begin the installation process, you need to have full access to a MySQL database. 
It can be an existing database, or you can create a new one; the later is preferable, 
but not required. 
Additionally, you have to have a web server to host the Statistics portal.

1. Copy the Statistics.jar to the /plugins/ directory of your Minecraft server. 
    Restart the server. The plugin will complain about the lack of 
    connection to the database - this is normal and expected.
2. Open /plugins/Statistics/config.yml and fill in the necessary MySQL database details. 
    Restart the server again.
3. The plugin will complete the initial set up of the database tables. 
    You will see the patch notification - please, be patient and wait 
    until the plugin says that the database is up to date.
4. The plugin installation is complete.
5. Copy the contents of the "statistics.zip" archive to the desired 
    directory on your web server. For example, /home/public_html/stats.
6. Make the cache and include/config dirs writable. (chmod 777)
7. Proceed to the URL associated with that directory and follow the 
    instructions on screen. For example http://example.com/stats/.
8. Portal installation is complete.